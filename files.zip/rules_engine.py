"""
Decision logic for Amy. Pure functions where possible so this is easy to
unit-test independently of Gmail / TAO access.
"""
from datetime import datetime, timedelta
from config import rules


class ActionNeeded(Exception):
    """Raised whenever the operating instructions say 'stop and create an
    ACTION NEEDED exception' rather than guess."""
    def __init__(self, issue, required_action):
        self.issue = issue
        self.required_action = required_action
        super().__init__(issue)


def normalize_guest_request(raw):
    """
    raw: dict parsed from the incoming email (see gmail_client.parse_request).
    Applies the guest-count and promoter rules from section 3.
    """
    female = raw.get("female_count") or 0
    male = raw.get("male_count") or 0
    try:
        female = int(female)
    except (TypeError, ValueError):
        female = 0
    try:
        male = int(male)
    except (TypeError, ValueError):
        male = 0

    if female == 0 and male == 0:
        raise ActionNeeded(
            issue="Both guest counts are zero \u2014 no party to register.",
            required_action="Confirm party size with the customer before processing.",
        )

    requested_venues = raw.get("venues") or []
    if isinstance(requested_venues, str):
        requested_venues = [v.strip() for v in requested_venues.split(",") if v.strip()]

    for v in requested_venues:
        if v in rules.PAUSED_VENUES:
            raise ActionNeeded(
                issue=f"{v} is paused and is not a fallback venue.",
                required_action="Do not submit. Wait for explicit reactivation.",
            )

    return {
        "first_name": raw.get("first_name") or raw.get("name", "").split(" ")[0],
        "last_name": raw.get("last_name", ""),
        "email": raw["email"],
        "phone": raw.get("phone") or rules.FALLBACK_PHONE,
        "billing_zip": raw.get("billing_zip") or rules.FALLBACK_BILLING_ZIP,
        "start_date": raw["start_date"],
        "end_date": raw["end_date"],
        "requested_venues": requested_venues,
        "female_count": female,
        "male_count": male,
        "promoter": raw.get("promoter"),
        "source_message_id": raw["source_message_id"],
    }


def date_range(start_date, end_date):
    d = datetime.fromisoformat(start_date).date()
    end = datetime.fromisoformat(end_date).date()
    out = []
    while d <= end:
        out.append(d)
        d += timedelta(days=1)
    return out


def is_dayclub_season(date_obj):
    return date_obj.month < rules.DAYCLUB_SEASON_END_MONTH


def default_route_for_date(date_obj):
    day_name = date_obj.strftime("%A")
    return rules.DEFAULT_ROUTING[day_name]


def apply_weekend_override(friday_venue, saturday_candidate):
    """Never repeat the same nightclub Fri+Sat; prefer Hakkasan Sat if Friday is JEWEL."""
    if saturday_candidate == friday_venue:
        if friday_venue == "JEWEL Nightclub":
            return "Hakkasan Nightclub"
        return "best_available"
    return saturday_candidate


def resolve_venue_for_date(request, date_obj, live_availability_checker):
    """
    live_availability_checker(venue, date_obj) -> dict or None
        Expected dict shape: {"event": str, "listing_type": "Passes"|"Tickets",
                               "female_cutoff": str, "male_cutoff": str, ...}
        Must return None if there is no live Passes/Guest List entry.

    Requested venue always has first priority (section 4). Falls back to the
    default routing table only when the requested venue has no valid listing.
    """
    candidates = list(request["requested_venues"]) or []
    route = default_route_for_date(date_obj)
    fallback = route["fallback"]
    if isinstance(fallback, list):
        candidates_fallback = fallback
    else:
        candidates_fallback = [fallback]
    ordered_candidates = candidates + [route["primary"]] + candidates_fallback

    for venue in ordered_candidates:
        if venue == "best_available":
            continue
        if venue in rules.PAUSED_VENUES:
            continue
        listing = live_availability_checker(venue, date_obj)
        if listing and listing.get("listing_type") == "Passes":
            return venue, listing

    return None, None
