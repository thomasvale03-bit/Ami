"""
Amy \u2014 Playmaker Entertainment guest-list processing agent.

Run modes:
    python main.py --dry-run   # parse + decide + draft output, no live TAO
                                # submission, no email sent (safe to test with)
    python main.py --live      # actually submits to TAO and sends confirmations

Intended deployment: a scheduled job (cron / cloud scheduler) that runs this
every few minutes. See README.md for hosting options.
"""
import argparse
import logging

from rules_engine import (
    normalize_guest_request, ActionNeeded, date_range,
    resolve_venue_for_date,
)
from templates.emails import consolidated_confirmation, internal_processed_record, internal_action_needed
import gmail_client
import tao_portal

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("amy")


def process_one_request(raw, dry_run=True):
    try:
        request = normalize_guest_request(raw)
    except ActionNeeded as e:
        return {"status": "action_needed", "issue": e.issue, "required_action": e.required_action}

    registrations = []
    exceptions = []

    for date_obj in date_range(request["start_date"], request["end_date"]):
        venue, listing = resolve_venue_for_date(
            request, date_obj,
            live_availability_checker=lambda v, d: (
                None if dry_run else tao_portal.check_availability(v, d)
            ),
        )
        if not venue:
            exceptions.append({
                "date": date_obj.isoformat(),
                "issue": "No matching live Passes/Guest List event for requested or routed venues.",
            })
            continue

        if dry_run:
            registrations.append({
                "venue": venue, "event": "[would be read from live listing]",
                "date": date_obj.isoformat(),
                "female_count": request["female_count"], "male_count": request["male_count"],
                "arrival_text": "[would be read from live listing]",
                "confirmation_id": "[DRY RUN \u2014 not submitted]",
            })
            continue

        result = tao_portal.submit_registration(listing, request)
        if not result.get("verified"):
            exceptions.append({"date": date_obj.isoformat(), "issue": "Submission could not be verified."})
            continue

        registrations.append({
            "venue": venue, "event": listing.get("event", ""), "date": date_obj.isoformat(),
            "female_count": request["female_count"], "male_count": request["male_count"],
            "arrival_text": listing.get("arrival_text", ""),
            "confirmation_id": result["confirmation_id"],
        })

    output = {"request": request, "registrations": registrations, "exceptions": exceptions}

    if registrations:
        date_label = request["start_date"] if request["start_date"] == request["end_date"] \
            else f"{request['start_date']} to {request['end_date']}"
        subject, body = consolidated_confirmation(
            request["first_name"], request["email"], date_label, registrations
        )
        output["confirmation_email"] = {"subject": subject, "body": body}
        output["internal_log"] = internal_processed_record(
            f"{request['first_name']} {request['last_name']}", request["email"],
            registrations, request.get("promoter"), "Not sent (dry run)" if dry_run else "Pending send",
        )

    for exc in exceptions:
        output.setdefault("action_needed_records", []).append(
            internal_action_needed(
                f"{request['first_name']} {request['last_name']}", request["email"],
                venue=", ".join(request["requested_venues"]) or "(none specified)",
                date=exc["date"], issue=exc["issue"],
                required_action="Review live TAO availability manually or adjust routing.",
            )
        )

    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true", help="Actually submit + send email")
    args = parser.parse_args()
    dry_run = not args.live

    service = gmail_client.get_service()
    pending = gmail_client.list_pending_requests(service)
    log.info("Found %d pending guest-list request(s)", len(pending))

    for msg_ref in pending:
        msg, body = gmail_client.get_plain_text_body(service, msg_ref["id"])
        raw = gmail_client.parse_request(msg_ref["id"], body)
        if raw.get("_missing_required"):
            log.warning("Skipping %s \u2014 missing fields: %s", msg_ref["id"], raw["_missing_required"])
            continue

        result = process_one_request(raw, dry_run=dry_run)
        log.info("Processed %s: %s", msg_ref["id"], result.get("status", "ok"))
        # TODO: send result["confirmation_email"] via gmail_client, then
        # label the source message Playmaker/Processed or Playmaker/Exception.


if __name__ == "__main__":
    main()
