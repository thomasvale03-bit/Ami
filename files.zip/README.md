# Amy \u2014 Playmaker guest-list agent

This is a working scaffold, not a finished, deployable bot. It encodes your
real operating rules and inbox structure, and it's structured so the two
genuinely hard parts \u2014 Gmail auth and TAO form automation \u2014 are isolated
and clearly marked. Bring this into Claude Code to finish and deploy it.

## What's real right now
- `config/rules.py` \u2014 your actual venue list, routing table, and cutoff
  rules, taken directly from the Playmaker operating instructions.
- `rules_engine.py` \u2014 the decision logic (guest-count defaults, paused
  venues, requested-venue-first priority, weekend no-repeat rule, exception
  conditions). This is unit-testable on its own, no live services needed.
- `gmail_client.py` \u2014 a real Gmail API search query matched to your actual
  subject lines, and a field parser matched to your actual form field labels
  (confirmed against your screenshots: Name, Email, Visit start/end date,
  Venues, Female/Male guests).
- `templates/emails.py` \u2014 your exact approved confirmation wording.

## What's stubbed and needs finishing (`tao_portal.py`)
Submitting to `tickets.taogroup.com` requires browser automation
(Playwright), and the exact page structure has to be captured by recording
a real logged-in session \u2014 that can't be done blind from a chat. In Claude
Code:

```
playwright codegen https://tickets.taogroup.com/promoter/68d79ff5-3d04-4198-83d7-00330a1e6107
```

Click through checking one real event and submitting one real test guest.
Codegen will spit out the exact selectors \u2014 drop them into the `TODO`
blocks in `check_availability()` and `submit_registration()`.

## Gmail auth (one-time)
1. In Google Cloud Console, create a project, enable the Gmail API, create
   an OAuth client (type: Desktop App).
2. Run a one-time local auth flow for `valeconsultingaz@gmail.com` to
   produce `token.json` (standard `google-auth-oauthlib` installed-app flow
   \u2014 ask Claude Code to scaffold this script if you don't have one).
3. Keep `token.json` and your OAuth client secret out of source control.

## Running it
```
pip install -r requirements.txt
playwright install chromium
python main.py --dry-run     # parses real inbox, decides routing, drafts
                              # output \u2014 does NOT touch TAO or send email
python main.py --live        # only after tao_portal.py selectors are filled in
```

## Deploying so it actually runs 24/7
Once `--live` works correctly against a handful of real requests:
- Cheapest: a scheduled Cloud Function / Cloud Run job that runs `main.py`
  every 2\u20135 minutes.
- Simplest to manage: a small always-on VM (Render/Railway/a $5\u2013$10/mo box)
  running this on a cron loop.
Either way, Claude Code can help you write the deployment config once the
core logic is verified.

## Not yet decided (flagged in the operating instructions)
- No "not qualified" customer-facing email exists yet \u2014 right now, an
  unavailable request just creates an internal ACTION NEEDED record instead
  of emailing the customer. Decide the wording before going live if you want
  customers notified automatically either way.
- Drai's is hard-paused in `config/rules.py` until you say otherwise.
